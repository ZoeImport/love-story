
#include <utility>
#include <vector>

int partition(std::vector<std::pair<int, int>> &arr, int low, int high);
void quickSort(std::vector<std::pair<int, int>> &arr, int low, int high);
void bubbleSort(std::vector<std::pair<int, int>> &arr);
void insertionSort(int arr[], int n);