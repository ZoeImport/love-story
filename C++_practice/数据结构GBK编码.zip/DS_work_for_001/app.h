#include "ClothesOrder.h"
#include "List.h"
#include <iostream>
#include <vector>

void menuMsg();
int showListAsc(LinkedList<ClothesOrder> *&list);
int appFunction(LinkedList<ClothesOrder> *&list);
int initOrderList(LinkedList<ClothesOrder> *&list);